/**
 * Class to model a single student.
 * @author COMP
 *
 */
public class Student {
    /**
     * contains AndrewId.
     */
    private String AndrewId;
    /**
     * contains firstname.
     */
    private String FirstName;
    /**
     * contains lastname.
     */
    private String LastName;
    /**
     * contains phonenumber.
     */
    private String PhoneNumber;
    /**
     * my constructor.
     * @param andrewId andrew id of the student
     */
    public Student(String andrewId) {
        AndrewId = andrewId;
    }
    /**
     * get AndrewId.
     * @return AndrewId
     */
    public String getAndrewId() {
        return AndrewId;
    }
    /**
     * get FirstName.
     * @return FirstName
     */
    public String getFirstName() {
        return FirstName;
    }
    /**
     * get LastName.
     * @return LastName
     */
    public String getLastName() {
        return LastName;
    }
    /**
     * get PhoneNumber.
     * @return PhoneNumber
     */
    public String getPhoneNumber() {
        return PhoneNumber;
    }
    /**
     * set FirstName.
     * @param s new student
     */
    public void setFirstName(String s) {
        if (FirstName == null) {
            FirstName = s;
        }
    }
    /**
     * set LastName.
     * @param s new student
     */
    public void setLastName(String s) {
        if (LastName == null) {
            LastName = s;
        }
    }
    /**
     * set PhoneNumber.
     * @param s new student
     */
    public void setPhoneNumber(String s) {
        if (PhoneNumber == null) {
            PhoneNumber = s;
        }
    }
    /**
     * toString method.
     * @return string equivalent.
     */
    public String toString() {
        return FirstName + ' ' + LastName + " (Andrew ID: "
    + AndrewId + ", Phone Number: " + PhoneNumber + ')';
    }
}
